from .web_analyzer import analyze_domain

__all__ = ['analyze_domain']
